<?php 
define('HOST', 'localhost');
define('DB', 'dbbannuoc');
define('USER', 'root');
define('PW', '');

define('PAGE_SIZE', 4);
?>
