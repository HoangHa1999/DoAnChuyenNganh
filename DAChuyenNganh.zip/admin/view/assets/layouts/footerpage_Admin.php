<div class="footer clearfix mb-0 text-muted">
                    <div class="float-start">
                        <p><?php echo date("Y")?> &copy; TH</p>
                    </div>
                    <div class="float-end">
                        <p>Được chế tác <span class="text-danger"><i class="bi bi-heart"></i></span> bởi <a
                                href="http://thcoffee.xyz">TH</a></p>
                    </div>
                </div>
                <script src="assets/vendors/perfect-scrollbar/perfect-scrollbar.min.js"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>

    <script src="assets/js/main.js"></script>