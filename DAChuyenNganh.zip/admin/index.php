<script>
    location.href = 'view/index.php';
</script>
